# Kütüphaneleri ekliyorum. Bunları internetten buldum, umarım eksik yoktur :)
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

# Flask uygulamasını başlatıyoruz. __name__ olayını tam anlamadım ama kopyaladığım yerde böyle yazıyordu.
app = Flask(__name__)

# Gizli anahtar! Bu çok önemliymiş, kimseye söylemeyin lütfen :D
app.config['SECRET_KEY'] = 'premium_taskflow_secret_key_123!'

# Veritabanı dosyası oluşturuyoruz, sqlite en kolayı dediler o yüzden bunu seçtim. Şirket falan kurarsak postgresql'e geçeriz herhalde.
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///tasks.db'

# Bildirimleri kapattım, saçma sapan uyarı verip duruyordu konsolda.
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Veritabanını uygulamaya bağlıyorum
db = SQLAlchemy(app)

# Login işleri için login manager kurdum, valla çok karışıkmış ama chatgpt sağolsun biraz çözdüm.
login_manager = LoginManager(app)
login_manager.login_view = 'login' # the route for login (giriş yapmayanları buraya yollasın)
login_manager.login_message = "Lütfen önce giriş yapın." # Kendi mesajımı yazdım daha havalı durdu Türkçe olması.

# Kullanıcılar için veritabanı tablosu oluşturuyorum. Her class bir tablo oluyormuş.
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True) # Herkesin bir ID'si olmalı
    username = db.Column(db.String(150), unique=True, nullable=False) # Aynı isimden iki tane olmaz dedim, unique yaptım
    password_hash = db.Column(db.String(150), nullable=False) # Şifreyi normal kaydetmiyorum, şifreliyorum hackerlar falan bulamaz (çooook profesyonelim)
    
    # Kullanıcının görevlerini buraya bağladım. cascade falan varmış, kullanıcı silinirse görevleri de peşinden gitsin diye. Yetim kalmasınlar :P
    tasks = db.relationship('Task', backref='owner', lazy=True, cascade="all, delete-orphan")

# Bu da asıl görevleri tutacağımız tablo. Todo list uygulaması sonuçta :)
class Task(db.Model):
    id = db.Column(db.Integer, primary_key=True) # Görev ID'si
    content = db.Column(db.String(200), nullable=False) # Görevin kendisi, boş olamaz
    priority = db.Column(db.String(20)) # Acil mi değil mi falan
    deadline = db.Column(db.String(20)) # Son tarih için text açtım valla, datetime çok zor geldi orda.
    status = db.Column(db.String(20), default='todo') # todo, in_progress, done (başta hepsi todo yani yapılacak)
    
    # Ne zaman oluşturulduğu saat
    created_at = db.Column(db.DateTime, default=datetime.utcnow) 
    
    # Hangi kullanıcıya ait olduğunu burda belirliyoruz. Foreign key bağlamak beynimi yaktı ama oldu galiba.
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False) 

    # Bunu bir yerlerden bulup yazdım JSON'a çevirmek için lazımmış API falan kullanırken.
    def to_dict(self):
        return {
            'id': self.id,
            'content': self.content,
            'priority': self.priority,
            'deadline': self.deadline,
            'status': self.status,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S')
        }

# Kullanıcıyı hafızaya alıyor galiba. Session işleri hep bundan soruluyor
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# İlk defa çalıştırırken tablolar oluşsun diye bunu ekledim. Önceden veritabanı hatası yiyordum bu çözdü.
with app.app_context():
    db.create_all()

# =========== SAYFA YÖNLENDİRMELERİ (ROUTING) ===========

# Burası giriş sayfası, hem sayfayı gösteriyor (GET) hem formu alıyor (POST)
@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("index")) # Zaten hesabına girmişse direk içeri atıyorum adamı yormayalım.
        
    if request.method == "POST":
        data = request.get_json() # JavaScript'ten (fetch ile) gelen verileri aldım
        username = data.get("username")
        password = data.get("password")
        
        # Veritabanında öyle bir kullanıcı adı var mı diye arıyorum
        user = User.query.filter_by(username=username).first()
        
        # Eğer varsa şifresine bakıyorum uyuyor mu diye
        if user and check_password_hash(user.password_hash, password):
            login_user(user) # Sisteme giriş yaptırdım oh be
            return jsonify({"success": True})
            
        # Şifre veya isim yanlışsa fırça kayıyorum
        return jsonify({"success": False, "message": "Geçersiz kullanıcı adı veya şifre"}), 401
        
    return render_template("login.html") # Sadece sayfaya girdiyse html'i göster

# Yeni adam kayıt etme yeri
@app.route("/register", methods=["POST"])
def register():
    data = request.get_json()
    username = data.get("username")
    password = data.get("password")
    
    # İsim zaten alınmışsa hata verdiriyorum, milletin hesabına falan çökmeyelim
    if User.query.filter_by(username=username).first():
        return jsonify({"success": False, "message": "Kullanıcı adı zaten alınmış"}), 400
        
    # Yeni adamı kaydediyorum, şifreyi de hash fonksiyonuyla kilitliyorum.
    new_user = User(username=username, password_hash=generate_password_hash(password))
    db.session.add(new_user)
    db.session.commit() # Tabi commit demezsek gitmiyor veritabanına, onu dün öğrendim :P
    
    login_user(new_user) # Kayıt olunca hemen oturumunu açsın da uğraşmasın
    return jsonify({"success": True})

# Çıkış yap butonu
@app.route("/logout")
@login_required # Giriş yapmadan çıkamaz herhalde mantıken
def logout():
    logout_user() # Bu fonksiyon ne güzelmiş kendi hallediyor her şeyi
    return redirect(url_for("login")) # Tekrar giriş sayfasına yallah

# Anasayfaya giden yol
@app.route("/")
@login_required # İzinsiz giremezler! Buraya dekoratör deniyormuş fiyakalı isim
def index():
    return render_template("index.html")

# =========== API KISIMLARI (Frontend JavaScript buraya istek atıyor) ===========

# Görevleri listeleyen API
@app.route("/api/tasks")
@login_required # Çakal biri linkten bizim verileri çalmasın diye burayı da kilitledim
def get_tasks():
    search = request.args.get("search")
    query = Task.query.filter_by(user_id=current_user.id) # Sadece bu adama ait olanları getir
    
    # Eğer adam arama kutusuna bir şey yazdıysa SQL ile filtreliyorum LIKE komutu falan vuruyor herhalde arkada
    if search:
        query = query.filter(Task.content.contains(search))
        
    # En yeni görevler en üstte çıksın diye tarihe göre tersten sıraladım (.desc() yani descending iningizcemi konuşturdum)
    tasks = query.order_by(Task.created_at.desc()).all()
    
    # İstatistikler için ufak bi hesap kitap işlemi yaptım matematikte fena değilizdir
    total = len(tasks)
    completed = len([t for t in tasks if t.status == 'done'])
    percent = int((completed / total) * 100) if total > 0 else 0
        
    # Bunları sözlük olarak paketleyip yolluyorum ki benim javascript anlasın
    return jsonify({
        "tasks": [task.to_dict() for task in tasks],
        "stats": {
            "total": total,
            "completed": completed,
            "percent": percent
        }
    })

# Yeni görev ekleme yeri
@app.route("/api/add", methods=["POST"])
@login_required
def add():
    data = request.get_json()
    content = data.get("task")
    priority = data.get("priority", "Normal")
    deadline = data.get("deadline", "")

    # Boş görev göndermesin gıcık olurum, if content diyip kontrol ediyorum
    if content:
        new_task = Task(content=content, priority=priority, deadline=deadline, user_id=current_user.id)
        db.session.add(new_task)
        db.session.commit()
        return jsonify({"success": True, "task": new_task.to_dict()})
        
    return jsonify({"success": False, "message": "Görev içeriği boş olamaz"}), 400

# Sürükle bırak yapınca burası çalışıyor, id felan url'den alıyoruz
@app.route("/api/update_status/<int:id>", methods=["POST"])
@login_required
def update_status(id):
    # first_or_404 kullanınca eğer görev adamın değilse anında şutluyor çok iyi
    task = Task.query.filter_by(id=id, user_id=current_user.id).first_or_404()
    data = request.get_json()
    new_status = data.get('status')
    
    # Kendi kafasına göre status girmesin diye array içinde arattım
    if new_status in ['todo', 'in_progress', 'done']:
        task.status = new_status
        db.session.commit()
        return jsonify({"success": True, "task": task.to_dict()})
        
    return jsonify({"success": False, "message": "Geçersiz durum"}), 400

# Çöpe at butonuna basınca buraya geliyor
@app.route("/api/delete/<int:id>", methods=["DELETE"])
@login_required
def delete(id):
    # Önce kendi görevimi diye bi bakıyoruz
    task = Task.query.filter_by(id=id, user_id=current_user.id).first_or_404()
    db.session.delete(task)
    db.session.commit() # Silince de commit atıyormuşuz.
    return jsonify({"success": True})

# Projemi localhost'ta fise takılan yer burası.
if __name__ == "__main__":
    # debug=True en sevdiğim olay, hata olunca bana söylüyor yoksa kafayı yerim. Canlıya çıkarken kapatın dediler.
    app.run(debug=True)